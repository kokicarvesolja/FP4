print("home") 
